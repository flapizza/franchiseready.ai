import { Button, Card } from "@/feature/ui";

type Props = {
  status: string;
  readiness: number;
  confidence: number;
  nextAction: string;
  objective: string;
  decisionWindow: string;
};

export function AICommandCenter({
  status,
  readiness,
  confidence,
  nextAction,
  objective,
  decisionWindow,
}: Props) {
  return (
    <Card
      title="AI Command Center"
      subtitle="Your executive briefing for the next candidate interaction."
    >
      <div className="space-y-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              Candidate Status
            </p>

            <div className="mt-2 inline-flex rounded-full bg-emerald-100 px-4 py-2 text-sm font-semibold text-emerald-700">
              {status}
            </div>
          </div>

          <div className="text-right">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              AI Confidence
            </p>

            <p className="mt-2 text-4xl font-bold text-blue-600">
              {confidence}%
            </p>
          </div>
        </div>

        <div className="rounded-2xl border border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50 p-8">
          <p className="text-xs font-semibold uppercase tracking-wide text-blue-700">
            Next Best Action
          </p>

          <h2 className="mt-3 text-3xl font-bold text-slate-900">
            {nextAction}
          </h2>

          <p className="mt-5 max-w-3xl leading-7 text-slate-700">
            {objective}
          </p>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          <Metric
            label="Readiness"
            value={`${readiness}/100`}
          />

          <Metric
            label="Decision Window"
            value={decisionWindow}
          />

          <Metric
            label="Confidence"
            value={`${confidence}%`}
          />
        </div>

        <div className="flex flex-wrap gap-4 border-t border-slate-200 pt-6">
          <Button>
            Start Discovery
          </Button>

          <Button variant="secondary">
            Generate Brief
          </Button>

          <Button variant="secondary">
            Email Candidate
          </Button>

          <Button variant="ghost">
            Assessment
          </Button>
        </div>
      </div>
    </Card>
  );
}

type MetricProps = {
  label: string;
  value: string;
};

function Metric({
  label,
  value,
}: MetricProps) {
  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
        {label}
      </p>

      <p className="mt-2 text-3xl font-bold text-slate-900">
        {value}
      </p>
    </div>
  );
}